use traning;
select * from employee;

create table empolyee2 
(
id  int primary key,
name varchar(30) not null,
dept varchar(30),
age int check(age>22)
);

desc empolyee2;
desc employee;

insert into empolyee2 values(1,'john','hr',32);
insert into empolyee2 values(2,'john','hr',23);
insert into empolyee2(id, name) values(2,'Abhishek');