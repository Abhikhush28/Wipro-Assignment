create database traning;
/**
It is used to select the database
*/
use traning;


create table employee
(
id int,
name varchar(20),
dept varchar(30),
salary float,
age int
);


insert into employee values(1, 'Abhishek', 'Developer', 93000.6, 21);
insert into employee values(1, 'Aditya', 'Hr', 6000, 20);
insert into employee(id,name,dept) values(2, 'Abhijit' , 'Admin');
insert into employee values(3, 'Ankit', 'Developer', 7300.76,30),
							(4, 'Abhi', 'WebDev', 65000.76,30),
                            (5, 'Shuruti', 'tester', 1000000.76,20);
							



select * from employee;
select id , name from employee;
select id, name, dept from employee;
select id, name, dept, salary from employee;



update employee set salary=6000000, age=21 where id=2;

show tables;
create table Product 
(
id int,
name varchar(30),
description varchar(30)
);

describe Product;

/** 
adding the coloumn
*/
alter table Product add  price int;
alter table Product add column( quantity int, supplierName varchar(30));

/**
Rename a column
*/
alter table product rename column supplierName to SupplyName;
/** 
Droping the column
*/
alter table product drop SupplyName;
alter table product modify column description varchar(100);

/**
rename the table
*/
rename table product2  to product;


/**
Drop the table 
*/
drop table Product;
truncate Product;

/**
 
*/
select id, name, salary , salary+2000 from employee;
select id, name, salary , salary+2000 as bonus , salary/30 as perdaySalary from employee;


select * from employee;
select * from employee where dept='Hr';
select * from employee where dept!='Hr';
select * from employee where dept='Hr' or dept='Admin';
select * from employee where dept='Developer' and age>20;
select * from employee where dept='Developer' or  age>20;


select * from employee order by age;
select * from employee order by salary;
select * from employee order by salary desc;

select * from employee where dept='Developer' order by salary desc;
select sum(salary) from employee;
select count(id) from employee;
select max(id) from employee;
select min(id) from employee;

select dept  from employee  group by dept;

/**
alogn with group by  we have to do some aggregate functions
*/
select dept, count(id) from employee group by dept;
select dept, sum(salary) from employee group by dept;



