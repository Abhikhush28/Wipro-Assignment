create table student 
(
id int,
name varchar(30),
subject varchar(30),
marks int
);


insert into student values (1,'rahul','math',78);
insert into student values (2,'sahich','Physichs',80);
insert into student values (3,'rohiy','english',90);
insert into student values (4,'rahul','math',89);
insert into student values (5,'sahich','Physichs',70);
insert into student values (6,'rohiy','english',78);
insert into student values (7,'rahul','math',72);
insert into student values (8,'sahich','Physichs',58);
insert into student values (9,'rohiy','english',88);
insert into student values (10,'rahul','math',98);
insert into student values (11,'sahich','Physichs',48);
insert into student values (12,'rohiy','english',88);

select * from student;
select id, name, subject, marks, dense_rank() over (partition by subject order by marks desc);