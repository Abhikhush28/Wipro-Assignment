/*
Creating a new database LibraryDB
*/
create database LibraryDB;

/*
Switch to the LibraryDB database
*/
Use LibraryDB;

/*
create table Books
*/
create table Books (
book_id int primary key,
title varchar(255) not null,
author varchar(255) not null,
publication_year int,
genre varchar(50),
Isbn varchar(255) unique,
available_copies int check (available_copies >=0)
);

/*
Create a author table
*/
create table Authors 
(
author_id int primary key,
author_name varchar(255) not null
);


/*
Create member table
*/
create table Member (
member_id int primary key,
member_name varchar(255) not null,
email varchar(255),
phone_number varchar(20)
);


/*
Create Borrowing table
*/
create table Borrowings (
borrowing_id int primary key,
book_id int,
member_id int,
borrow_date date,
return_date date,
status varchar(20) check (status in ( 'borrowed', 'returned')),
foreign key (book_id) references Books(book_id),
foreign key (member_id) references Member(member_id)
);

/*
Alter book table to add new column  'language'
*/
alter table books add column langauge varchar(50);

Drop table authors;











