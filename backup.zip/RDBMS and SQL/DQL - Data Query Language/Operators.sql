Select * from employee;

select * from employee where name like 's%';