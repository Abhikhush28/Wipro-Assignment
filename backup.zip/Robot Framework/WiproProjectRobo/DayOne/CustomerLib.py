class CustomerLib:
    def Greet(self, name):
        return f"First Name: {name}"
