import json
import os

EMPLOYEE_FILE = 'employees.json'


def load_employees():
    # Load employee from Json file
    if not os.path.exists(EMPLOYEE_FILE):
        return []

    with open(EMPLOYEE_FILE, 'r') as file:
        return json.load(file)


def save_employee(employees):
    # Save  employee to the json file
    with open(EMPLOYEE_FILE, 'w') as file:
        json.dump(employees, file, indent=4)


def add_employee(employee):
    #add a new employee
    employees = load_employees()
    employees.append(employee)
    save_employee(employees)


def get_employee(employee_id):
    # Retrieve a employee by Id.
    employees = load_employees()
    for employee in employees:
        if employee['id'] == employee_id:
            return employee

    return None


def update_employee(employee_id, updated_info):
    employees = load_employees()
    for employee in employees:
        if employee['id'] == employee_id:
            employee.update(updated_info)
            save_employee(employees)
            return True
    return False


def delete_employee(employee_id):
    employees = load_employees();
    new_employees = [emp for emp in employees if emp['id'] != employee_id]

    if len(new_employees) == employees:
        return False
    save_employee(new_employees)
    return True


def generate_report():
    employees = load_employees()
    for emp in employees:
        print(f"ID: {emp['id']}, Name: {emp['name']}, Position: {emp['position']}, Salary: {emp['salary']}")


new_employee = {
    'id': 2,
    "name": "Abhishek Kumar",
    "position": "Software Engineer",
    "salary": 90000
}

add_employee(new_employee)
emp = get_employee(1)
print(f"Retrieved Details: {emp}")

# update employee details
update_info = {
    "position": "Software Developer",
    "salary": 90000
}

update_employee(1, update_info)

print("\nEmployee Report:")
generate_report()

# #Delete a Employee
# delete_employee(1)
#
# print("\n Employee Report After Deletion: ")
# generate_report()
