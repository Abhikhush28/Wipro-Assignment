import os
import xml.etree.ElementTree as ET

PRODUCTS_FILE = "products.xml"

# Function to add a new product to the catalog
def add_product(id, name, price, description):
    tree = ET.parse(PRODUCTS_FILE)
    root = tree.getroot()

    product = ET.SubElement(root, "product")
    ET.SubElement(product, "id").text = id
    ET.SubElement(product, "name").text = name
    ET.SubElement(product, "price").text = str(price)
    ET.SubElement(product, "description").text = description

    tree.write(PRODUCTS_FILE)

# Function to update product information
def update_product(product_id, name=None, price=None, description=None):
    tree = ET.parse(PRODUCTS_FILE)
    root = tree.getroot()

    for product in root.findall("product"):
        if product.find("id").text == product_id:
            if name:
                product.find("name").text = name
            if price:
                product.find("price").text = str(price)
            if description:
                product.find("description").text = description

    tree.write(PRODUCTS_FILE)

# Function to delete a product by its ID
def delete_product(product_id):
    tree = ET.parse(PRODUCTS_FILE)
    root = tree.getroot()

    for product in root.findall("product"):
        if product.find("id").text == product_id:
            root.remove(product)

    tree.write(PRODUCTS_FILE)

# Function to retrieve product details by its ID
def get_product_details(product_id):
    tree = ET.parse(PRODUCTS_FILE)
    root = tree.getroot()

    for product in root.findall("product"):
        if product.find("id").text == product_id:
            return {
                "name": product.find("name").text,
                "price": float(product.find("price").text),
                "description": product.find("description").text
            }
    return None

# Function to initialize the XML file if it doesn't exist
def initialize_products_file():
    if not os.path.exists(PRODUCTS_FILE):
        root = ET.Element("catalog")
        tree = ET.ElementTree(root)
        tree.write(PRODUCTS_FILE)

# Initialize the products file if it doesn't exist
initialize_products_file()

# Example usage
add_product("1", "Laptop", 999.99, "High-performance laptop with SSD storage")
add_product("2", "Smartphone", 499.99, "5G-enabled smartphone with dual-camera setup")

# update_product("1", price=899.99)

# delete_product("2")

# Example of retrieving product details
product_details = get_product_details("2")
if product_details:
    print("Product Name:", product_details["name"])
    print("Product Price:", product_details["price"])
    print("Product Description:", product_details["description"])
else:
    print("Product not found.")
