def read_file(filename):
    try:
        with open(filename, 'r') as file:
            for line in file:
                print(line.strip())  # Remove trailing newline characters
    except FileNotFoundError:
        print(f"File '{filename}' not found.")

# Example usage:
filename = "example.txt"  # Change this to the path of your file
read_file(filename)
