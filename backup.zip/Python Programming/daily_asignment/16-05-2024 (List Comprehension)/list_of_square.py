# Task 2: Write a list comprehension that creates a list of squares for all even numbers between 0 and 20.
squares = [x**2 for x in range(1, 21) if x % 2 == 0]
print(squares)