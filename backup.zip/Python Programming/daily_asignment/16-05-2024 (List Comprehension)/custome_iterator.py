class ReverseIter:
    def __init__(self, lst):
        self.lst = lst
        self.index = len(lst)

    def __iter__(self):
        return self

    def __next__(self):
        self.index -= 1
        if self.index >= 0:
            return self.lst[self.index]
        else:
            raise StopIteration


my_list = [1, 2, 3, 4, 5]
reverse_iterator = ReverseIter(my_list)
for item in reverse_iterator:
    print(item)
