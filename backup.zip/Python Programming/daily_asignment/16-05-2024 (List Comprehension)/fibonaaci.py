def fib_gen(n):
    a, b = 0, 1
    while a <= n:
        yield a
        a, b = b, a + b


n = 100 
for num in fib_gen(n):
    print(num, end=" ")
