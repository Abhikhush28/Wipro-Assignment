word_list = ["apple", "banana", "orange", "grape", "kiwi", "mango", "pear"]

filtered_words = filter(lambda word: len(word) > 4, word_list)

result = list(filtered_words)

print(result)
