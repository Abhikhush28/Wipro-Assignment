import sqlite3

def connect_to_database(database_name):
    # Connect to SQLite database file (or create it if it doesn't exist)
    conn = sqlite3.connect(database_name)
    return conn

def create_books_table(cursor):
    # Create a table named 'books' with columns title, author, and year
    cursor.execute('''CREATE TABLE IF NOT EXISTS books
                      (title TEXT, author TEXT, year INTEGER)''')

def insert_books(cursor, books_data):
    # Insert multiple rows of data into the 'books' table
    cursor.executemany('''INSERT INTO books (title, author, year)
                          VALUES (?, ?, ?)''', books_data)

def select_book_by_title(cursor, title):
    # Select a book by its title
    cursor.execute("SELECT * FROM books WHERE title=?", (title,))
    book = cursor.fetchone()
    return book

def update_author(cursor, title, new_author):
    # Update the author of a book
    cursor.execute("UPDATE books SET author=? WHERE title=?", (new_author, title))

def delete_book(cursor, title):
    # Delete a book from the 'books' table
    cursor.execute("DELETE FROM books WHERE title=?", (title,))


# Connect to database
conn = connect_to_database('library.db')
cursor = conn.cursor()

# Create the 'books' table if it doesn't exist
create_books_table(cursor)

# Sample data to be inserted into the 'books' table
books_data = [
        ('To Kill a Mockingbird', 'Harper Lee', 1960),
        ('1984', 'George Orwell', 1949),
        ('The Great Gatsby', 'F. Scott Fitzgerald', 1925),
        ('Pride and Prejudice', 'Jane Austen', 1813)
    ]

# Insert sample data into the 'books' table
insert_books(cursor, books_data)

# Select a book by title
book_title = '1984'
selected_book = select_book_by_title(cursor, book_title)
print(selected_book)


