import sqlite3

# Connect to SQLite database file (or create it if it doesn't exist)
conn = sqlite3.connect('library.db')

# Create a cursor object to execute SQL commands
cursor = conn.cursor()

# Create a table named 'books' with columns title, author, and year
cursor.execute('''CREATE TABLE IF NOT EXISTS books
                  (title TEXT, author TEXT, year INTEGER)''')

# Sample data to be inserted into the 'books' table
books_data = [
    ('To Kill a Mockingbird', 'Harper Lee', 1960),
    ('1984', 'George Orwell', 1949),
    ('The Great Gatsby', 'F. Scott Fitzgerald', 1925),
    ('Pride and Prejudice', 'Jane Austen', 1813)
]

# Insert multiple rows of data into the 'books' table
cursor.executemany('''INSERT INTO books (title, author, year)
                      VALUES (?, ?, ?)''', books_data)

# Commit the changes to the database
conn.commit()

# Close the connection
conn.close()

print("database created successfully")
