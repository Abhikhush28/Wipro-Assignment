import requests
base_url = 'https://jsonplaceholder.typicode.com'
endpoint = '/users'

new_user_details = {
    "id": 1,
    "name": "Abhishek",
    "username": "Abhi@3134",
    "email": "abhi@gmail.com",
    "address": {
        "street": "vihar",
        "suite": "Apt. 556",
        "city": "patna",
        "zipcode": "92998-3874",
        "geo": {
            "lat": "-37.3159",
            "lng": "81.1496"
        }
    },
    "phone": "1-770-736-8031 x56442",
    "website": "wipro.com",
    "company": {
        "name": "Wipro",
        "catchPhrase": "Multi-layered client-server neural-net",
        "bs": "harness real-time e-markets"
    }
}

response = requests.post(f"{base_url}{endpoint}", json=new_user_details)

if response.status_code == 201:
    res = response.json()
    print(response.status_code)
    print(res)
else:
    print('Error: ', response.status_code)