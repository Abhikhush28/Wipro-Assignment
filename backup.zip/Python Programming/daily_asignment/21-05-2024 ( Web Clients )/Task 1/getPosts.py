
import requests
base_url = 'https://jsonplaceholder.typicode.com'
endpoint = '/posts'

response = requests.get(f"{base_url}{endpoint}")
if response.status_code == 200:
    print(response.status_code)
    res = response.json()
    print(res)
    # users = res.get('user',{})
    for post in res:
        print(f"\nPost ID : {post['id']},"
              f"Title: {post['title']}"
              f"Body : {post['body']}" )
else:
    print('Error: ', response.status_code)
