
# Task 1 :- Use the requests library in Python to make a GET request to a public API and print the response.
import requests
base_url = 'https://jsonplaceholder.typicode.com'
endpoint = '/users'

response = requests.get(f"{base_url}{endpoint}")
if response.status_code == 200:
    print(response.status_code)
    res = response.json()
    print(res)
    # users = res.get('user',{})
    for user in res:
        print(f"User Id: {user['id']},"
              f"Email id: {user['email']}"
              f"Name: {user['name']}"
              f"UserName: {user['username']}")
else:
    print('Error: ', response.status_code)
