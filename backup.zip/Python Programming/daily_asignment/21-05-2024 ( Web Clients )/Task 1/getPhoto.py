
import requests
base_url = 'https://jsonplaceholder.typicode.com'
endpoint = '/photos'

response = requests.get(f"{base_url}{endpoint}")
if response.status_code == 200:
    print(response.status_code)
    res = response.json()
    print(res)
    # users = res.get('user',{})
    for photo in res:
        print(f"\nImage ID : {photo['id']},"
              f"Title: {photo['title']}"
              f"Image Url : {photo['url']}" )
else:
    print('Error: ', response.status_code)
