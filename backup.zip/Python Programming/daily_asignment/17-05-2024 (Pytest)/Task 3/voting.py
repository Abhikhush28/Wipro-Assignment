import pytest


def check_voting_age(age):
    if age < 18:
        raise ValueError("Age must be 18 or above to vote")
    return "You are eligible to vote"

def test_check_voting_age():
    # Valid input, no exception should be raised
    assert check_voting_age(20) == "You are eligible to vote"

    # Invalid input, exception should be raised
    with pytest.raises(ValueError):
        check_voting_age(16)
