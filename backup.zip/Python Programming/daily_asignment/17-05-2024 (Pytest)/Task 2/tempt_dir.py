import pytest
import os
import tempfile

@pytest.fixture
def temp_dir(request):
    temp_dir = tempfile.mkdtemp()
    print("Temporary directory created:", temp_dir)

    def fin():
        os.rmdir(temp_dir)
        print("Temporary directory deleted:", temp_dir)

    request.addfinalizer(fin)
    return temp_dir

def test_temp_dir_creation_1(temp_dir):
    assert os.path.exists(temp_dir)

def test_temp_dir_creation_2(temp_dir):
    assert os.path.exists(temp_dir)
