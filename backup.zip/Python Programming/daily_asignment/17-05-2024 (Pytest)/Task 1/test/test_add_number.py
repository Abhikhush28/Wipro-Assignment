import pytest
from src.add_number import add_numbers


def test_add_number():
    assert add_numbers(10,20) == 30
    assert add_numbers(0,0) == 0
    assert add_numbers(-10,20) == 10
    assert add_numbers(10,-20) == -10
    assert add_numbers(-10,-20) == -30
