import pytest

from src.divide import divide_numbers


def test_divide_numbers():

    with pytest.raises(ZeroDivisionError):
        assert divide_numbers(10,0)

    with pytest.raises(ZeroDivisionError):
        assert divide_numbers(5,0)

    assert divide_numbers(10, 2) == 5
    assert divide_numbers(14, 2) == 7
    assert divide_numbers(10, 2) == 5
    assert divide_numbers(10, 2) == 5

