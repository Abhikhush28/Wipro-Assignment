import requests

try:
    base_url = 'http://reqres.in'
    endpoint = '/api/users/2'
    response = requests.get(f"{base_url}{endpoint}", timeout=0.25)
    # response = requests.get(f"{base_url}{endpoint}")
    if response.status_code == 200:
        print("Resquest Was Successfull (Status Code : ", response.status_code , ")")
        print("Response Content: ", response.text)
    else:
        print("Error: ", response.status_code)

    response.raise_for_status()
except requests.exceptions.HTTPError as http_err:
    print("Http Error ocurred: ", http_err)
except requests.exceptions.ConnectionError as conn_err:
    print("Error Connecting to the server: ",conn_err)
except requests.exceptions.Timeout as timeout_err:
    print("Timeout Error Ouccured: ", timeout_err)
except requests.exceptions.RequestException as req_err:
    print("Timeout Error Ouccured: ", req_err)
