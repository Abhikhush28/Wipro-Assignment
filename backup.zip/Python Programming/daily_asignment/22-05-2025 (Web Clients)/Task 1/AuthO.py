import requests
login_response = requests.post('https://reqres.in/api/login', data={
    "email": "eve.holt@reqres.in",
    "password": "cityslicka"
})
if login_response.status_code == 200:
    res = login_response.json()
    tok = res['token']
    print(tok)
else:
    print("ERROR code ", login_response.status_code)